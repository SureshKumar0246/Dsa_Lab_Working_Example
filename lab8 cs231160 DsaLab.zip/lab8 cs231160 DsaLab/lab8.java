

class lab8 {

    static class Node {
        int data;
        Node left, right;


        Node(int data) {
           this. data = data;
            left = right = null;
        }
    }


    // Task 1: Calculate the level (height) of the binary tree
    public int calculateLevel(Node root) {
        if (root == null) {
            return 0;
        }
        int leftHeight = calculateLevel(root.left);
        int rightHeight = calculateLevel(root.right);
        return Math.max(leftHeight, rightHeight) + 1;
    }

    // Task 2: Check if the tree is a Complete Tree, Full Tree, or Both
    public boolean isCompleteTree(Node root) {
        if (root == null) return true;
        int nodeCount = countNodes(root);
        return isCompleteTreeUtil(root, 0, nodeCount);
    }

    private boolean isCompleteTreeUtil(Node root, int index, int nodeCount) {
        if (root == null) return true;

        if (index >= nodeCount) return false;

        return isCompleteTreeUtil(root.left, 2 * index + 1, nodeCount) &&
                isCompleteTreeUtil(root.right, 2 * index + 2, nodeCount);
    }

    private int countNodes(Node root) {
        if (root == null) return 0;
        return 1 + countNodes(root.left) + countNodes(root.right);
    }

    public boolean isFullTree(Node root) {
        if (root == null) return true;
        if (root.left == null && root.right == null) return true;
        if (root.left != null && root.right != null) {
            return isFullTree(root.left) && isFullTree(root.right);
        }
        return false;
    }

    public void CompleteFull(Node root) {
        if (isCompleteTree(root) && isFullTree(root)) {
            System.out.println("The tree is both Complete and Full.");
        } else if (isCompleteTree(root)) {
            System.out.println("The tree is Complete but not Full.");
        } else if (isFullTree(root)) {
            System.out.println("The tree is Full but not Complete.");
        } else {
            System.out.println("The tree is neither Complete nor Full.");
        }
    }

    // Task 3: Check the Children Sum Property
    public boolean checkChildrenSumProperty(Node root) {
        if (root == null || (root.left == null && root.right == null)) {
            return true;
        }

        int leftData = (root.left != null) ? root.left.data : 0;
        int rightData = (root.right != null) ? root.right.data : 0;


        if (root.data == leftData + rightData &&
                checkChildrenSumProperty(root.left) && checkChildrenSumProperty(root.right)) {
            return true;
        }
        return false;
    }


    public static void main(String[] args) {
        lab8 tree = new lab8();
        Node root = new Node(10);
        root.left = new Node(8);
        root.right = new Node(2);
        root.left.left = new Node(3);
        root.left.right = new Node(5);
        root.right.left = new Node(2);

        // Task 1: Calculate level (height) of the binary tree
        System.out.println("Height of the binary tree: " + tree.calculateLevel(root));

        // Task 2: Check if the tree is Complete and/or Full
        tree.CompleteFull(root);

        // Task 3: Check if Children Sum Property holds
        if (tree.checkChildrenSumProperty(root)) {
            System.out.println("The tree satisfies the Children Sum Property.");
        } else {
            System.out.println("The tree does not satisfy the Children Sum Property.");
        }
    }
}
