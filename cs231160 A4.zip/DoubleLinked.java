
public class DoubleLinked {

    Node head;
    Node tail;

    static class Node {
        int data;
        Node prev;
        Node next;

        public Node(int data) {
            this.data = data;
            this.prev = null;
            this.next = null;
        }
    }
    public void insertAtBeg(int newdata) {
        Node newnode = new Node(newdata);

        if (head == null) {
            head = newnode;
            tail = newnode;
        } else {
            head.prev = newnode;
            newnode.next = head;
            head = newnode;
        }
    }

    public void insertAtEnd(int newdata) {
        Node newnode = new Node(newdata);

        if (tail == null)
        {
            head = newnode;
            tail = newnode;
        } else {
            tail.next = newnode;
            newnode.prev = tail;
            tail = newnode;
        }
    }


    public void deleteStart() {
        if (head == null) {
            System.out.println("List is empty. Nothing to delete.");
            return;
        }
        if (head == tail)
        {
            head = null;
            tail = null;
        } else {
            head = head.next;
            head.prev = null;
        }
        System.out.println("Node deleted from the beginning.");
    }

    // Method to delete a node from the end
    public void deleteEnd() {
        if (tail == null) {
            System.out.println("List is empty. Nothing to delete.");
            return;
        }
        if (head == tail)
        {
            head = null;
            tail = null;
        } else {
            tail = tail.prev;
            tail.next = null;
        }
        System.out.println("Node deleted from the end.");
    }


    public void printList() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " --> ");
            current = current.next;
        }
        System.out.println("null");
    }

    public static void main(String[] args) {
        // Creating nodes in the main method
        DoubleLinked list = new DoubleLinked();

        // Insert at the start
        list.insertAtBeg(10);
        list.insertAtBeg(20);
        list.insertAtBeg(30);

        // Insert at the end
        list.insertAtEnd(40);
        list.insertAtEnd(50);
        list.insertAtEnd(60);

        // Printing forward
        System.out.println("Elements in List:");
        list.printList();

        list.deleteStart();
        list.deleteEnd();

        System.out.println("List After Deleting from start and end");
        list.printList();
    }
}
