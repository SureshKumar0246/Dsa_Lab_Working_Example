
public class DoubleLinked2{

    Node head;
    Node tail;

    static class Node {
        int data;
        Node prev;
        Node next;

        public Node(int data) {
            this.data = data;
            this.prev = null;
            this.next = null;
        }
    }
    public void insertBeg(int newdata) {
        Node newnode = new Node(newdata);

        if (head == null) {
            head = newnode;
            tail = newnode;
        } else {
            head.prev = newnode;
            newnode.next = head;
            head = newnode;
        }
    }

    public void insertEnd(int newdata) {
        Node newnode = new Node(newdata);

        if (tail == null)
        {
            head = newnode;
            tail = newnode;
        } else {
            tail.next = newnode;
            newnode.prev = tail;
            tail = newnode;
        }
    }

    public void printList() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " --> ");
            current = current.next;
        }
        // Ending at null
        System.out.println("null");
    }

    public void printListBackward() {
        Node current = tail;
        while (current != null) {
            System.out.print(current.data + " --> ");
            current = current.prev;
        }
        System.out.println("null");
    }

    public static void main(String[] args) {

        DoubleLinked2 list = new DoubleLinked2();

        list.insertBeg(10);
        list.insertBeg(20);
        list.insertBeg(30);

        list.insertEnd(40);
        list.insertEnd(50);

        System.out.println("Forward Traversal:");
        list.printList();

        System.out.println("Backward Traversal:");
        list.printListBackward();
    }
}

