import java.util.*;

class TreeNode {
    int value;
    TreeNode left, right;

    public TreeNode(int value) {
        this.value = value;
        this.left = this.right = null;
    }
}

class ExpressionNode {
    String value;
    ExpressionNode left, right;

    public ExpressionNode(String value) {
        this.value = value;
        this.left = this.right = null;
    }
}

public class TreeOperations {


    public static class ExpressionTree {


        public ExpressionNode buildExpressionTree() {

            ExpressionNode root = new ExpressionNode("/");


            root.left = new ExpressionNode("*");
            root.left.left = new ExpressionNode("+");
            root.left.left.left = new ExpressionNode("5");
            root.left.left.right = new ExpressionNode("2");
            root.left.right = new ExpressionNode("-");
            root.left.right.left = new ExpressionNode("2");
            root.left.right.right = new ExpressionNode("1");


            root.right = new ExpressionNode("+");
            root.right.left = new ExpressionNode("2");
            root.right.right = new ExpressionNode("9");

            return root;
        }

        // Inorder traversal to print the expression
        public void inorderTraversal(ExpressionNode node) {
            if (node != null) {
                inorderTraversal(node.left);
                System.out.print(node.value + " ");
                inorderTraversal(node.right);
            }
        }
    }

    // 2) Convert a Sorted Array into BST
    public static class SortedArrayToBST {

        public TreeNode sortedArrayToBST(int[] nums) {
            return sortedArrayToBSTHelper(nums, 0, nums.length - 1);
        }

        private TreeNode sortedArrayToBSTHelper(int[] nums, int start, int end) {
            if (start > end) return null;

            int mid = start + (end - start) / 2;
            TreeNode node = new TreeNode(nums[mid]);

            node.left = sortedArrayToBSTHelper(nums, start, mid - 1);
            node.right = sortedArrayToBSTHelper(nums, mid + 1, end);

            return node;
        }


        public void inorder(TreeNode node) {
            if (node != null) {
                inorder(node.left);
                System.out.print(node.value + " ");
                inorder(node.right);
            }
        }
    }

    // 3) Convert a Binary Tree into BST
    public static class BinaryTreeToBST {

        List<Integer> values = new ArrayList<>();

        // Step 1: Store elements of Binary Tree in a list (Inorder Traversal)
        void storeInorder(TreeNode node) {
            if (node != null) {
                storeInorder(node.left);
                values.add(node.value);
                storeInorder(node.right);
            }
        }

        // Step 2: Convert sorted values list to BST
        TreeNode sortedListToBST(int start, int end) {
            if (start > end) return null;

            int mid = start + (end - start) / 2;
            TreeNode node = new TreeNode(values.get(mid));

            node.left = sortedListToBST(start, mid - 1);
            node.right = sortedListToBST(mid + 1, end);

            return node;
        }

        // Convert Binary Tree to BST
        TreeNode convertToBST(TreeNode root) {
            if (root == null) return null;

            // Step 1: Store values of Binary Tree
            storeInorder(root);

            // Step 2: Sort values
            Collections.sort(values);

            // Step 3: Build BST using sorted values
            return sortedListToBST(0, values.size() - 1);
        }

        // Inorder Traversal to verify BST
        void inorder(TreeNode node) {
            if (node != null) {
                inorder(node.left);
                System.out.print(node.value + " ");
                inorder(node.right);
            }
        }
    }

    public static void main(String[] args) {
        // Part 1: Binary Expression Tree
        ExpressionTree expressionTree = new ExpressionTree();
        ExpressionNode expRoot = expressionTree.buildExpressionTree();
        System.out.print("Inorder Traversal of Expression Tree: ");
        expressionTree.inorderTraversal(expRoot);
        System.out.println();

        // Part 2: Sorted Array to BST
        SortedArrayToBST sortedArrayToBST = new SortedArrayToBST();
        int[] sortedArray = {-10, -3, 0, 5, 9};
        TreeNode bstRootFromArray = sortedArrayToBST.sortedArrayToBST(sortedArray);
        System.out.print("Inorder Traversal of BST from Sorted Array: ");
        sortedArrayToBST.inorder(bstRootFromArray);
        System.out.println();

        // Part 3: Binary Tree to BST
        TreeNode root = new TreeNode(10);
        root.left = new TreeNode(30);
        root.right = new TreeNode(15);
        root.left.left = new TreeNode(20);
        root.left.right = new TreeNode(5);

        BinaryTreeToBST binaryTreeToBST = new BinaryTreeToBST();
        TreeNode bstRootFromTree = binaryTreeToBST.convertToBST(root);
        System.out.print("Inorder Traversal of Converted BST from Binary Tree: ");
        binaryTreeToBST.inorder(bstRootFromTree);
        System.out.println();
    }
}
