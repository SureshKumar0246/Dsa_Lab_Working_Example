import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class ReverseKQueue {

    public static Queue<Integer> reverseElement(Queue<Integer> queue, int k){
        if (queue == null || k>queue.size() || k<=0){
            return queue;
        }
        Stack<Integer> stack = new Stack<>();
        for (int i = 0; i<k; i++){
            stack.push(queue.poll());
        }
        while (!stack.isEmpty()){
            queue.add(stack.pop());
        }
        for (int i = 0; i<queue.size()-k; i++){
            queue.add(queue.poll());
        }
        return queue;
    }
    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<>();

        queue.add(20);
        queue.add(30);
        queue.add(40);
        queue.add(50);
        queue.add(60);

        System.out.println(queue);

        int k = queue.size();
        queue = reverseElement(queue, k);
        System.out.println("Revered Element are "+queue);

    }
}
