import java.util.LinkedList;
import java.util.Queue;

public class GetMinimum {
    static class minQueue{
        Queue<Integer> queue = new LinkedList<>();
        Queue<Integer> minQueue = new LinkedList<>();

        public void  add(int element){
            queue.add(element);
            while (!minQueue.isEmpty() && minQueue.peek()>element){
                minQueue.poll();
            }
            minQueue.add(element);
        }
        public int getMin(){
            return minQueue.peek();
        }

    }
    public static void main(String[] args) {
minQueue queue = new minQueue();
queue.add(20);
        queue.add(30);
        queue.add(40);
        queue.add(10);
        queue.add(60);

        System.out.println(queue.getMin());


    }
}
