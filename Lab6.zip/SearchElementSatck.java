public class SearchElementSatck {
    static class Node{
        int data;
        Node next;
        Node(int data){
            this.data = data;
            this.next = null;
        }

    }
    static class Stack{
        static Node head = null;
        public static void push(int data){
            Node newNode = new Node(data);

            if (head==null){
                head =newNode;
            }
            else {
                newNode.next = head;
                head = newNode;
            }
        }
        public static boolean isEmpty(){
            return head ==null;
        }
        public static int pop(){
            if (isEmpty()){
                System.out.println("Stack is full");
                return -1;
            }
            Node temp = head;
            head = head.next;
            return temp.data;
        }
public static int peek(){
    if (isEmpty()){
        System.out.println("Stack is full");
        return -1;
    }
    return head.data;
}
        public static int searchItem(Stack stack, int element) {
            int index = 0;
            Node temp = head;
            while (temp != null) {
                if (temp.data == element) {
                    return index;
                }
                temp = temp.next;
                index++;
            }
//            int pos = -1;
//            int index = 0;
//            while (!stack.isEmpty()){
//                if (stack.peek() == element){
//                    pos = index;
//                }
//                stack.pop();
//                index++;
//            }
//            return pos;
            return index = -1;
        }
    }
    public static void main(String[] args) {
   Stack stack = new Stack();
   stack.push(20);
        stack.push(30);
        stack.push(40);
        stack.push(50);
        stack.push(60);

       int pos =  stack.searchItem(stack, 40);

        System.out.println(pos);
    }
}
