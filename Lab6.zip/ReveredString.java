public class ReveredString {
    static class Node{
        char data;
        Node next;

        Node(char data){
            this.data = data;
            this.next = null;
        }
    }
    static class Stack{
        public static Node head =  null;
        public void push(char str){
            Node newNode = new Node(str);
            if (head == null){
                head = newNode;
            }
            else {
                newNode.next = head;
                head = newNode;
            }

        }
        public boolean isEmpty(){
            return head == null;
        }
        public char pop(){
            if (isEmpty()){
                System.out.println("Stack is empty");
                return 'n';
            }
            Node temp = head;
            head = head.next;
            return temp.data;
        }
    }
    public static void main(String[] args) {
Stack stack = new Stack();
String text = "12345";
for (char ch: text.toCharArray()){
     stack.push(ch);
}
while (!stack.isEmpty()){
    System.out.print(stack.pop());
}
    }
}
